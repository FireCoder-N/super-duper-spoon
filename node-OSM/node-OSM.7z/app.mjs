import express from 'express';
//import './db.mjs';
import {connectDb, getDb} from "./db.mjs"

const port = process.env.PORT || '3001';

//middleware
const app = express();

//connect to database
let db;

connectDb((err) => {
	if(!err) {
		app.listen(3001, () => {
			console.log('darkness imprisoning me, all I can see, absolute horror');
			console.log(`http://127.0.0.1:${port}`);
		});
		db = getDb();
	}
});

//routes and handlers
app.get('/', async (req,res) => {
	
	let submissions = db.collection('submissions').find({});
	while (await submissions.hasNext()) {
		console.log(await submissions.next());
	}	
	
	//db.collection('submission').deleteOne({name:"test0"});
	db.collection('submissions').insertOne(
		{
			"locationID": "13a",
			"submitterID": "Μάκης Κοντογιαννίδης",
			"mainCategory": "Ηλεκτρολογικά",
			"subCategory": "Φωτισμός",
			"comments": "",
			"date": "15-02-2022"	
		}
		);
	
	res.json({mssg: "die of death"});
});